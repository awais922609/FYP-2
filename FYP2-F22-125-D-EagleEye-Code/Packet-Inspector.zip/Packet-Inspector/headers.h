#ifndef headers_h
#define headers_h
#include <netinet/ip6.h>
#include <vector>
#include <bits/stdc++.h>
#include <chrono>
#include <time.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/icmp6.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h>
#include <linux/if_packet.h>
#include <signal.h>
#include <net/if.h>
#include <iostream>
#include <cstring>
#include <string>
#include <stdio.h>
#include "output.h"


//sql headers 
#include <mysql_connection.h>
#include <mysql_driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <cppconn/prepared_statement.h>




using namespace std;



#endif