#include <iostream>
#include <mysql_connection.h>
#include <mysql_driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>

using namespace std;

main()
{
	sql::Driver *driver;
sql::Connection *con;
driver = get_driver_instance();
con = driver->connect("tcp://127.0.0.1:3306", "newuser", "password");
con->setSchema("fyp");


 sql::ResultSet* res;
sql::Statement *stmt;
stmt = con->createStatement();
stmt->execute("drop table test");
stmt->execute("CREATE TABLE test (  id INT NOT NULL AUTO_INCREMENT,  name VARCHAR(50) NOT NULL,  PRIMARY KEY (id));");
//stmt->execute("INSERT INTO test (name) VALUES  ('John'),  ('Jane'),  ('Bob');");
res = stmt->executeQuery("select * from test");
while(res->next()){
cout<<" name "<<res->getString("name")<<endl;
}
con->close();
delete con;

	//cout << "give me a bottle of rum!" << endl;
	return 0;
}
