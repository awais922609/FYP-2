#include "csrf_detector.h"
#include "headers.h"
#include "xss_detector.h"

bool check_ssrf_payload(string data_payload, string payload) {
    size_t found = data_payload.find(payload);
    if (found != string::npos) {
        return true;
    }
    return false;
}

void SSRF_Detector(char *data_payload, string source_ip , string destination_ip){

    string file_name = "ssrf_payload.txt";
    ifstream infile(file_name);
    string payload;

    if (!infile) {
        cout << "Error opening file: " << file_name << endl;
    }

    while (getline(infile, payload)) {
        if (check_ssrf_payload(data_payload, payload)) {
            cout<<"\n SSRF Payload Detected ....";
            cout << "\nPayload >>" << payload << " << found in data payload." << endl;
             string str = " SSRF Payload Detected .... Payload is >> " + payload + " << found in data payload Source IP attacking is  >> " + source_ip + " << and Destination IP is >> " + destination_ip + " << ";
                         sql::Driver *driver;
sql::Connection *con;
driver = get_driver_instance();
con = driver->connect("tcp://127.0.0.1:3306", "newuser", "password");
con->setSchema("fyp");

sql::Statement *stmt;
stmt = con->createStatement();
sql::PreparedStatement* pstmt = con->prepareStatement("INSERT INTO logs (source_IP,dest_IP,payload,attack) VALUES (?,?,?,?)");
            pstmt->setString(1, source_ip);
            pstmt->setString(2, destination_ip);
            pstmt->setString(3, payload);
            pstmt->setString(4, "SSRF");
            pstmt->executeUpdate();


// Execute the query to get the current count of web attacks
sql::ResultSet* res;
res = stmt->executeQuery("SELECT web_attacks FROM atcount WHERE id=1");

// Check if the result set is valid and move the cursor to the first row
if (res->next()) {
    // Get the current count of web attacks from the result set
    int x = res->getInt("web_attacks");

    // Increment the count by 1
    x++;

    // Update the count of web attacks in the database
    sql::PreparedStatement* pstmt2 = con->prepareStatement("UPDATE atcount SET web_attacks = ? WHERE id = 1");
    pstmt2->setInt(1, x);
    pstmt2->executeUpdate();

    // Free the prepared statement object
    delete pstmt2;
}
else {
    // Handle the case when the result set is empty or invalid
    cout << "Error: Result set is empty or invalid" << endl;
}

// Free the result set object
delete res;



                con->close();
delete con;
        }
    }

    infile.close();
}