#Compiling the file
g++ packet.cpp -o a.out

#Running the File
sudo ./a.out wlan0

//wlan0 interface for capturing the packets