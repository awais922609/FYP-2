#ifndef scan_DETECTOR_H
#define scan_DETECTOR_H
#include "headers.h"
#include <random>

void scan_Detector() {
  // conect to DB and retrive the data
  sql::Driver *driver;
  sql::Connection *con;
  driver = get_driver_instance();
  con = driver->connect("tcp://127.0.0.1:3306", "newuser", "password");
  con->setSchema("fyp");

  sql::ResultSet *res, *res2;
  sql::Statement *stmt;
  stmt = con->createStatement();
  res = stmt->executeQuery("SELECT DISTINCT source_IP,dest_IP FROM ips;");

  while (res->next()) {
    string sip = res->getString("source_IP");
    string dip = res->getString("dest_IP");

    sql::PreparedStatement *pstmt = con->prepareStatement(
        "SELECT COUNT(DISTINCT dest_port) FROM ips WHERE source_IP = ?");
    pstmt->setString(1, sip);
    res2 = pstmt->executeQuery();
    if (res2->next()) {
      int distinct_ports = res2->getInt(1);
      cout << "\n==============" << distinct_ports << "=================\n";
      if (distinct_ports >= 50) {
        res2 = stmt->executeQuery(
            "SELECT network_attacks FROM atcount WHERE id=1");

        // Check if the result set is valid and move the cursor to the first row
        if (res2->next()) {
          // Get the current count of web attacks from the result set
          int x = res2->getInt("network_attacks");

          // Increment the count by 1
          x++;

          // Update the count of web attacks in the database
          sql::PreparedStatement *pstmt2 = con->prepareStatement(
              "UPDATE atcount SET network_attacks = ? WHERE id = 1");
          pstmt2->setInt(1, x);
          pstmt2->executeUpdate();

          pstmt = con->prepareStatement(
              "delete from ips where source_IP=?;");
          pstmt->setString(1, sip);
           pstmt->executeUpdate();



          pstmt = con->prepareStatement(
              "INSERT INTO logs (source_IP,dest_IP,payload,attack) VALUES "
              "(?,?,?,?)");
          pstmt->setString(1, sip);
          pstmt->setString(2, dip);
          pstmt->setString(3, "TCP scan");
          pstmt->setString(4, "Scaning network");
          pstmt->executeUpdate();

          // con->close();
          //  Free the prepared statement object
          delete pstmt2;
        } else {
          // Handle the case when the result set is empty or invalid
          cout << "Error: Result set is empty or invalid" << endl;
        }
      }
    }
  }
  con->close();
}

#endif
